import React from 'react';

const Clientes = () => {
    return (
        <div>
            <h1>Página de Clientes obsoleta</h1>
            <p>A gestão de clientes foi movida para o módulo "Pessoas".</p>
        </div>
    );
};

export default Clientes;